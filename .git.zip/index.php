<?php //hello world hello have a nice day
header("Location: /client_side/admin.php"); ?>

